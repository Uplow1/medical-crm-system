import React, { useState, useEffect } from "react";
import API from "../api";

const Patients = () => {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ name: "", age: "", condition: "" });

  const load = async () => {
    const r = await API.get("/patients");
    setList(r.data);
  };

  const save = async () => {
    await API.post("/patients", form);
    load();
  };

  useEffect(()=>{ load(); },[]);

  return (
    <div>
      <div className="card">
        <h3>Add Patient</h3>
        <input placeholder="Name" onChange={e=>setForm({...form,name:e.target.value})}/><br/>
        <input placeholder="Age" onChange={e=>setForm({...form,age:e.target.value})}/><br/>
        <input placeholder="Condition" onChange={e=>setForm({...form,condition:e.target.value})}/><br/><br/>
        <button onClick={save}>Submit</button>
      </div>

      <div className="card">
        <h3>Patients List</h3>
        {list.map(p => <p key={p.id}>{p.name} — {p.condition}</p>)}
      </div>
    </div>
  );
};

export default Patients;
