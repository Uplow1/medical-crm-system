import React, { useState, useEffect } from "react";
import API from "../api";

const QMS = () => {
  const [queue, setQueue] = useState([]);
  const [token, setToken] = useState("");

  const load = async () => {
    const r = await API.get("/qms");
    setQueue(r.data);
  };

  const generate = async () => {
    const r = await API.post("/qms/token");
    setToken(r.data.token);
  };

  const join = async () => {
    await API.post(`/qms/join/${token}`);
    load();
  };

  useEffect(()=>{ load(); },[]);

  return (
    <>
      <div className="card">
        <h3>Queue Management System</h3>
        <button onClick={generate}>Generate Token</button>
        {token && <p>Your Token: {token}</p>}
        {token && <button onClick={join}>Join Queue</button>}
      </div>

      <div className="card">
        <h3>Queue List</h3>
        {queue.map(q => <p key={q.id}>{q.token} — {q.status}</p>)}
      </div>
    </>
  );
};

export default QMS;
