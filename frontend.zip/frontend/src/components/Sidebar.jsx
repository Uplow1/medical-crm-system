import React from "react";

const Sidebar = ({ setPage }) => {
  return (
    <div className="sidebar">
      <h2>Medical CRM</h2>
      <button onClick={() => setPage("dashboard")}>Dashboard</button>
      <button onClick={() => setPage("patients")}>Patients</button>
      <button onClick={() => setPage("appointments")}>Appointments</button>
      <button onClick={() => setPage("qms")}>Queue (QMS)</button>
      <button onClick={() => setPage("ai")}>AI Assistant</button>
    </div>
  );
};

export default Sidebar;
