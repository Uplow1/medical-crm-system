import React, { useState } from "react";
import API from "../api";

const AIChat = () => {
  const [query, setQuery] = useState("");
  const [msgs, setMsgs] = useState([]);

  const send = async () => {
    const r = await API.get(`/ai?q=${query}`);
    setMsgs([...msgs, { q: query, a: r.data.response }]);
  };

  return (
    <div className="card">
      <h3>AI Medical Assistant</h3>
      <input placeholder="Ask something..." onChange={e=>setQuery(e.target.value)} />
      <button onClick={send}>Send</button>
      <hr/>
      {msgs.map((m,i)=>(
        <p key={i}><b>You:</b> {m.q}<br/><b>AI:</b> {m.a}</p>
      ))}
    </div>
  );
};

export default AIChat;
