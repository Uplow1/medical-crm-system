const Dashboard = () => (
  <div className="card">
    <h3>Dashboard</h3>
    <p>Welcome to Medical CRM System</p>
  </div>
);

export default Dashboard;
