import React, { useState, useEffect } from "react";
import API from "../api";

const Appointments = () => {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ patient_id: "", date: "", doctor: "" });

  const load = async () => {
    const r = await API.get("/appointments");
    setList(r.data);
  };

  const save = async () => {
    await API.post("/appointments", form);
    load();
  };

  useEffect(()=>{ load(); },[]);

  return (
    <>
      <div className="card">
        <h3>Book Appointment</h3>
        <input placeholder="Patient ID" onChange={e=>setForm({...form,patient_id:e.target.value})}/><br/>
        <input placeholder="Date" onChange={e=>setForm({...form,date:e.target.value})}/><br/>
        <input placeholder="Doctor" onChange={e=>setForm({...form,doctor:e.target.value})}/><br/><br/>
        <button onClick={save}>Submit</button>
      </div>

      <div className="card">
        <h3>Appointments</h3>
        {list.map(a => <p key={a.id}>{a.patient_id} — {a.date} — {a.doctor}</p>)}
      </div>
    </>
  );
};

export default Appointments;
