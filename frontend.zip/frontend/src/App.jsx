import React, { useState } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import Patients from "./components/Patients";
import Appointments from "./components/Appointments";
import QMS from "./components/QMS";
import AIChat from "./components/AIChat";

const App = () => {
  const [page, setPage] = useState("dashboard");

  return (
    <div className="layout">
      <Sidebar setPage={setPage} />
      <div className="main">
        {page === "dashboard" && <Dashboard />}
        {page === "patients" && <Patients />}
        {page === "appointments" && <Appointments />}
        {page === "qms" && <QMS />}
        {page === "ai" && <AIChat />}
      </div>
    </div>
  );
};

export default App;
